# No documentation since this is a very limited library

#From here are all the functions

def co(pm)
    puts pm
end
 
def ad(pmm, pmmm)
    puts pmm + pmmm
end

def sub(subs, subss)
    puts subs - subss
end

def multi(mul, mull)
    puts mul * mull
end

def div(divv, divvv)
    puts divv / divvv
end

null = "No Value (NIL)"
pi = 3.14