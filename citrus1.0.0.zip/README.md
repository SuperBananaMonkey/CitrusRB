This is a very simple ruby library for oversimplifying simple tasks.

This library has very few useless functions for now, overtime, I will add more and more functions.

- 2024 "MrQuack"